import os
import torch
import torch.nn as nn
import torch.optim as optim

import functions
import U_Net_2D
from config import get_arguments

import time

# device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

def init_G(opt):
    netG = U_Net_2D.Generator(1, opt).to(opt.device)
    netG.apply(U_Net_2D.weights_init)
    return netG

def init_D(opt):
    netD = U_Net_2D.Discriminator(1).to(opt.device)
    netD.apply(U_Net_2D.weights_init)
    return netD

def generate_samples(netG, reals_shapes, noise_amp, condition_pyramid, n=1):

    # 创建生成的文件夹
    dir2save_parent = os.path.join(dir2save, 'random_samples')
    try:
        os.makedirs(dir2save_parent)
    except OSError:
        pass

    sample_conditioned = []

    # 循环生成
    for idx in range(n):
        noise = functions.sample_random_noise(opt.train_stages - 1, reals_shapes, opt)
        print(f'第{idx}张图片生成、修复开始...')
        with torch.no_grad():
            sample = netG(noise, reals_shapes, noise_amp, True, condition_pyramid) # post-GAN需要传递5个参数
        sample = functions.tackle_data(sample)

        functions.save_generate_image_as_txt(sample, idx, dir2save_parent)
        # 保存png或pdf
        functions.save_generate_image_as_png_or_pdf(sample, idx, dir2save)
        print(f'第{idx}张图片生成、修复结束！')
        sample_conditioned.append(sample)

    return sample_conditioned

if __name__ == '__main__':
    parser = get_arguments()
    parser.add_argument('--model_dir', help='input image name', required=True)
    parser.add_argument('--gpu', type=int, help='with GPU', default=0)
    parser.add_argument('--num_samples', type=int, help='generated random samples', default=10)
    parser.add_argument('--naive_img', help='naive input image (harmonization or editing)', default='')

    # 参数加载文件夹
    opt = parser.parse_args(['--model_dir', './params/'])
    _gpu = opt.gpu
    _naive_img = opt.naive_img
    __model_dir = opt.model_dir

    # 推断阶段，加载模型的opt参数
    opt = functions.load_config(opt=opt)
    opt.gpu = _gpu
    opt.naive_img = _naive_img
    opt.model_dir = __model_dir
    if torch.cuda.is_available():
        torch.cuda.set_device(opt.gpu)
        opt.device = "cuda:{}".format(opt.gpu)

    # 创建推断文件夹
    dir2save = os.path.join(opt.model_dir, "Evaluation")
    try:
        os.makedirs(dir2save)
    except OSError:
        pass


    real = functions.read_image(opt)

    print(f"******************************************************************原始训练图像{real.shape}最小值: {torch.min(real)}, 最大值: {torch.max(real)}")
    unique_values, counts = torch.unique(real, return_counts=True)
    # 打印每个值及其数量
    for value, count in zip(unique_values, counts):
        print(f"原始图片相值分布情况： {value.item()}: {count.item()} 个")

    real = functions.adjust_scale2image(real, opt)

    print(f"******************************************************************离散化训练图像{real.shape}最小值: {torch.min(real)}, 最大值: {torch.max(real)}")
    unique_values, counts = torch.unique(real, return_counts=True)
    # 打印每个值及其数量
    for value, count in zip(unique_values, counts):
        print(f"离散化图片相值分布情况： {value.item()}: {count.item()} 个")


    reals = functions.create_reals_pyramid(real, opt)

    for i in range(len(reals)):
        print(f"******************************************************************尺度{i}的训练图像{reals[i].shape}最小值: {torch.min(reals[i])}, 最大值: {torch.max(reals[i])}")
        unique_values, counts = torch.unique(reals[i], return_counts=True)
        # 打印每个值及其数量
        for value, count in zip(unique_values, counts):
            print(f"尺度{i}的图片相值分布情况： {value.item()}: {count.item()} 个")


    # 随机生成条件数据
    condition, condition_dict, location, well_1 = functions.generate_condition_samples(reals[-1], 15, 3, 44)


    print(f"******************************************************************原始条件图像{condition.shape}最小值: {torch.min(condition)}, 最大值: {torch.max(condition)}")
    unique_values, counts = torch.unique(condition, return_counts=True)
    # 打印每个值及其数量
    for value, count in zip(unique_values, counts):
        print(f"条件图片相值分布情况： {value.item()}: {count.item()} 个")

    condition = functions.adjust_scale2image_con(condition, opt)

    print(f"******************************************************************离散化条件图像{condition.shape}最小值: {torch.min(condition)}, 最大值: {torch.max(condition)}")
    unique_values, counts = torch.unique(condition, return_counts=True)
    # 打印每个值及其数量
    for value, count in zip(unique_values, counts):
        print(f"离散化条件图片相值分布情况： {value.item()}: {count.item()} 个")

    conditions_pyramid = functions.create_con_pyramid(condition, opt)

    for i in range(len(conditions_pyramid)):
        print(f"******************************************************************尺度{i}的条件图像{conditions_pyramid[i].shape}最小值: {torch.min(conditions_pyramid[i])}, 最大值: {torch.max(conditions_pyramid[i])}")
        unique_values, counts = torch.unique(conditions_pyramid[i], return_counts=True)
        # 打印每个值及其数量
        for value, count in zip(unique_values, counts):
            print(f"尺度{i}的条件图片相值分布情况： {value.item()}: {count.item()} 个")

    # 保存
    # functions.save_TI_as_txt(reals[-1])
    # functions.save_con_as_txt(conditions_pyramid[-1])
    # functions.save_con_as_sgems(conditions_pyramid[-1])
    # functions.plot_tensors(real_pyramid[-1], condition, file_format="png")

    location_pyramid = []
    for i, condition in enumerate(conditions_pyramid, 1):
        locations = torch.zeros_like(condition)
        locations[condition != 0] = 1
        location_pyramid.append(locations)

    reals_shapes = [r.shape for r in reals]

    import time

    # 更高精度的计时
    start_time = time.perf_counter()

    # 加载最细stage的生成器、固定噪声列表、真实数据金字塔、噪声权重列表
    netG = torch.load('%s/G.pth' % opt.model_dir, map_location='cuda:{}'.format(torch.cuda.current_device()))
    fixed_noise = torch.load('%s/fixed_noise.pth' % opt.model_dir, map_location='cuda:{}'.format(torch.cuda.current_device()))
    reals = torch.load('%s/reals.pth' % opt.model_dir, map_location='cuda:{}'.format(torch.cuda.current_device()))
    noise_amp = torch.load('%s/noise_amp.pth' % opt.model_dir, map_location='cuda:{}'.format(torch.cuda.current_device()))

    # 生成推断
    with torch.no_grad():
        realizations = generate_samples(netG, reals_shapes, noise_amp, conditions_pyramid, n=100)
        print('推理完成...')

    # 你的代码段在这里

    end_time = time.perf_counter()
    execution_time = end_time - start_time
    print(f"推理代码执行时间: {execution_time:.6f} 秒")

    # ***************************************************画图***************************************************
    for i, gen in enumerate(realizations, 1):
        unique_values, counts = torch.unique(gen, return_counts=True)
        # 打印每个值及其数量
        for value, count in zip(unique_values, counts):
            print(f"尺度{i}的生成图片相值分布情况： {value.item()}: {count.item()} 个")

    # 再写一个函数保存每一个单张的图片（realizations, condition_dict）
    functions.display_images_with_scatter_and_save(realizations, condition_dict, 'png')
