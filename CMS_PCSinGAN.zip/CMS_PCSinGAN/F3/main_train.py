import os
import torch

from config import get_arguments
import functions
from training_generation import training


if __name__ == '__main__':

    # 创建参数对象
    parser = get_arguments()
    # 添加参数：输入图像数据、gpu
    parser.add_argument('--input_name', help='input image name for training', required=True)
    parser.add_argument('--gpu', type=int, help='which GPU to use', default=0)
    parser.add_argument('--train_mode', default='generation', help='train mode only generations')
    parser.add_argument('--lr_scale', type=float, help='scaling of learning rate for lower stages', default=0.1)
    parser.add_argument('--train_stages', type=int, help='how many stages to use for training', default=8)

    # 输入数据实例化
    opt = parser.parse_args(['--input_name', ''])

    # 判断模型是否存在！
    if not os.path.exists(opt.input_name):
        print("Image does not exist: {}".format(opt.input_name))
        print("Please specify a valid image.")
        exit()

    real = functions.read_image(opt)

    print(f"******************************************************************原始训练图像{real.shape}最小值: {torch.min(real)}, 最大值: {torch.max(real)}")
    unique_values, counts = torch.unique(real, return_counts=True)
    # 打印每个值及其数量
    for value, count in zip(unique_values, counts):
        print(f"原始图片相值分布情况： {value.item()}: {count.item()} 个")

    real = functions.adjust_scale2image(real, opt)

    print(f"******************************************************************离散化训练图像{real.shape}最小值: {torch.min(real)}, 最大值: {torch.max(real)}")
    unique_values, counts = torch.unique(real, return_counts=True)
    # 打印每个值及其数量
    for value, count in zip(unique_values, counts):
        print(f"离散化图片相值分布情况： {value.item()}: {count.item()} 个")

    reals = functions.create_reals_pyramid(real, opt)

    for i in range(len(reals)):
        print(f"******************************************************************尺度{i}的训练图像{reals[i].shape}最小值: {torch.min(reals[i])}, 最大值: {torch.max(reals[i])}")
        unique_values, counts = torch.unique(reals[i], return_counts=True)
        # 打印每个值及其数量
        for value, count in zip(unique_values, counts):
            print(f"尺度{i}的图片相值分布情况： {value.item()}: {count.item()} 个")

    # 配置模型opt的设备：cpu或gpu
    opt = functions.post_config(opt)

    # 配置模型模型运行的设备：gpu
    if torch.cuda.is_available():
        torch.cuda.set_device(opt.gpu)

    # 创建模型保存的根目录：TrainedModels\Strebelle_250_250\test_for_concurrent_multistage_UNet_GAN
    dir2save = functions.generate_dir2save(opt)

    # 判断模型是否存在！
    if os.path.exists(dir2save):
        print('Trained model already exist: {}'.format(dir2save))
        exit()
    try:
        os.makedirs(dir2save)
    except OSError:
        pass

    # 保存模型训练的参数文件txt！
    with open(os.path.join(dir2save, 'parameters.txt'), 'w') as f:
        for o in opt.__dict__:
            f.write("{}\t-\t{}\n".format(o, opt.__dict__[o]))

    # 打印当前的文件目录
    print("Training model ({})".format(dir2save))

    import time

    # 更高精度的计时
    start_time = time.perf_counter()

    # 开始训练
    training(opt, reals)

    end_time = time.perf_counter()
    execution_time = end_time - start_time
    print(f"训练代码执行时间: {execution_time:.6f} 秒")



